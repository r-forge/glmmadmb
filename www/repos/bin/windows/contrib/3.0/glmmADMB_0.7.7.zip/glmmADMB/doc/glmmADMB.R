
## @knitr setopts,echo=FALSE
require("knitr")
opts_chunk$set(fig.width=5,fig.height=5,out.width="0.8\\textwidth",echo=TRUE)
Rver <- paste(R.version$major,R.version$minor,sep=".")


## @knitr graphopts,echo=FALSE
library("ggplot2")
library("grid")
theme_set(theme_bw())
zmargin <- theme(panel.margin=unit(0,"lines"))


## @knitr pkgversions,echo=FALSE
usedpkgs <- sort(c(##"coefplot2",
                 "ggplot2","glmmADMB","lme4","coda","scapeMCMC",
                   "bbmle","MASS"))
i1 <- installed.packages()
usedpkgs <- usedpkgs[usedpkgs %in% rownames(i1)]
print(i1[usedpkgs,"Version"],quote=FALSE)


## @knitr smartquotes,echo=FALSE
op <- options(useFancyQuotes=FALSE)


## @knitr citation
citation("glmmADMB")


## @knitr unsmartquotes,echo=FALSE
options(op)


## @knitr loadpkgs,message=FALSE,warning=FALSE
library("glmmADMB")
library("ggplot2")


## @knitr owltransform,warning=FALSE
Owls <- transform(Owls,
                  Nest=reorder(Nest,NegPerChick),
                  NCalls=SiblingNegotiation)


## @knitr owlplot1,echo=FALSE,warning=FALSE,fig.cap="Basic view of owl data (arrival time not shown). (FIXME: clip at zero?)",fig.ref="fig:owl1"
G0 <- ggplot(Owls,aes(x=reorder(Nest,NegPerChick),
                      y=NegPerChick))+
  xlab("Nest")+ylab("Negotiations per chick")+coord_flip()+
  facet_grid(FoodTreatment~SexParent)
G0+stat_sum(aes(size=..n..),alpha=0.5)+zmargin+
      scale_size_continuous(name="# obs",
                            breaks=seq(1,9,by=2))+
    theme(axis.title.x=theme_text(hjust=0.5,size=12),
         axis.text.y=theme_text(size=7))


## @knitr owlplot2,echo=FALSE,fig.cap="Basic view of owl data \\#2 (nest identity not shown)",fig.ref="fig:owl2"
G1 <- ggplot(Owls,aes(x=ArrivalTime,
                      y=NegPerChick,colour=FoodTreatment,
                      linetype=SexParent,
                      shape=SexParent))
G1+stat_sum(aes(size=factor(..n..)),alpha=0.5)+geom_smooth()+
      ## facet_grid(.~SexParent)+zmargin+
      labs(x="Arrival time",y="Negotiations per chick")+
      scale_size_discrete(name="# obs",
                          breaks=c("1","2"))


## @knitr time1,echo=FALSE,cache=TRUE
gt1 <- system.time(glmmadmb(NCalls~(FoodTreatment+ArrivalTime)*SexParent+
                                     offset(log(BroodSize))+(1|Nest),
                                     data=Owls,
                                     zeroInflation=TRUE,
                                     family="poisson"))


## @knitr glmmadmbfit,cache=TRUE
fit_zipoiss <- glmmadmb(NCalls~(FoodTreatment+ArrivalTime)*SexParent+
                                     offset(log(BroodSize))+(1|Nest),
                                     data=Owls,
                                     zeroInflation=TRUE,
                                     family="poisson")


## @knitr zipoisssum
summary(fit_zipoiss)


## @knitr coefplotmg1,fig.width=8,eval=FALSE
## library("coefplot2")
## coefplot2(fit_zipoiss)


## @knitr glmmadmbnbinomfit,cache=TRUE
fit_zinbinom <- glmmadmb(NCalls~(FoodTreatment+ArrivalTime)*SexParent+
                  offset(log(BroodSize))+(1|Nest),
                  data=Owls,
                  zeroInflation=TRUE,
                  family="nbinom")


## @knitr glmmadmbnbinom1fit,cache=TRUE
fit_zinbinom1 <- glmmadmb(NCalls~(FoodTreatment+ArrivalTime)*SexParent+
                                     offset(log(BroodSize))+(1|Nest),
                                     data=Owls,
                                     zeroInflation=TRUE,
                                     family="nbinom1")


## @knitr glmmadmbnbinom1vfit,cache=TRUE
fit_zinbinom1_bs <- glmmadmb(NCalls~(FoodTreatment+ArrivalTime)*SexParent+
                                     BroodSize+(1|Nest),
                                     data=Owls,
                                     zeroInflation=TRUE,
                                     family="nbinom1")


## @knitr aictab
library("bbmle")
AICtab(fit_zipoiss,fit_zinbinom,fit_zinbinom1,fit_zinbinom1_bs)


## @knitr cplot2,eval=FALSE
## vn <- c("food","arrivaltime","sex","food:sex","arrival:sex","broodsize")
## coefplot2(list(ZIP=fit_zipoiss,
##                ZINB=fit_zinbinom,
##                ZINB1=fit_zinbinom1,
##                ZINB1_brood=fit_zinbinom1_bs),
##           varnames=vn,
##           legend=TRUE)


## @knitr glmmadmbnbinomhfit,cache=TRUE
fit_hnbinom1 <- glmmadmb(NCalls~(FoodTreatment+ArrivalTime)*SexParent+
                         BroodSize+(1|Nest),
                         data=subset(Owls,NCalls>0),
                         family="truncnbinom1")


## @knitr glmmadmbcfit,cache=TRUE
Owls$nz <- as.numeric(Owls$NCalls>0)
fit_count <- glmmadmb(nz~1+(1|Nest),
                         data=Owls,
                         family="binomial")
fit_ccount <- glmmadmb(nz~(FoodTreatment+ArrivalTime)*SexParent+(1|Nest),
                       data=Owls,
                       family="binomial")
AICtab(fit_count,fit_ccount)
summary(fit_ccount)


## @knitr anovacomp
anova(fit_zipoiss,fit_zinbinom)


## @knitr caranova
car::Anova(fit_zinbinom)


## @knitr lme4_chunk1,eval=FALSE
## library("lme4")
## gm1_lme4 <- glmer(cbind(incidence, size - incidence) ~ period + (1 | herd),
##                   data = cbpp, family = binomial)
## gm1_glmmADMB <- glmmadmb(cbind(incidence, size - incidence) ~ period + (1 | herd),
##                   data = cbpp, family = "binomial")
## ## sessionInfo()
## fixef(gm1_lme4)
## fixef(gm1_glmmADMB) ## or coef()
## unlist(ranef(gm1_lme4))
## unlist(ranef(gm1_glmmADMB))
## VarCorr(gm1_lme4)
## detach("package:lme4")  ## kluge!
## VarCorr(gm1_glmmADMB)


## @knitr getlme4
library("lme4") 


## @knitr lme4glmmadmbconv,eval=FALSE
## ## seems to crash r-forge tests at the moment?
##  ## requires DEVELOPMENT version of lme4 ...
## new_lme4 <- packageVersion("lme4")>"0.999375.42"
## if (new_lme4) {
##     lme4fun <- update(gm1_lme4,devFunOnly=TRUE)
##     deviance(gm1_lme4)
##     lme4fun(c(0,fixef(gm1_lme4)))  ## variance set to zero
##     v1 <- getME(gm1_lme4,"theta")  ## log-Cholesky factor: equal in this case to standard dev
##     lme4fun(c(v1,fixef(gm1_lme4))) ## observed variance (*almost* identical)
##     v2 <- sqrt(gm1_glmmADMB$S[[1]])
##     lme4fun(c(v2,fixef(gm1_lme4))) ## ???
## }


## @knitr lme4glmmadmbconv2,eval=FALSE
## ## FIXME: figure out why this crashes knitr in non-interactive mode!!
## ## (then turn evaluation back on)
## glmmadmbfun <- function(pars,minval=exp(-9.5),verbose=FALSE) {
##     if (pars[1]==0) {
##         warning(sprintf("variance parameter set to min val (%f)",minval))
##         pars[1] <- minval
##     }
##     g0 <- glmmadmb(cbind(incidence, size - incidence) ~ period + (1 | herd),
##                    data = cbpp, family = "binomial",
##                    extra.args=c("-maxfn 1 -phase 6"),
##                    verbose=verbose,
##                    start=list(RE_sd=log(pars[1]), fixed=pars[-1]))
##     -logLik(g0)
## }
## ## glmmadmbfun(c(0,fixef(gm1_lme4)))  ## fails
## v2B <- glmmadmbfun(c(v2,fixef(gm1_lme4)))
## v1B <- glmmadmbfun(c(v1,fixef(gm1_lme4)))
## all.equal(v1B,v2B,-logLik(gm1_glmmADMB))


## @knitr loadowlmodel,echo=FALSE
getdata("OwlModel")


## @knitr fakeowlmodel,eval=FALSE
## OwlModel_nb1_bs_mcmc <- glmmadmb(NCalls~(FoodTreatment+ArrivalTime)*SexParent+
##                                      BroodSize+(1|Nest),
##                                      data=Owls,
##                                      zeroInflation=TRUE,
##                                      family="nbinom1",
##                                   mcmc=TRUE,
##                                   mcmc.opts=mcmcControl(mcmc=50000))


## @knitr loadcodapkg
library("coda")
m <- OwlModel_nb1_bs_mcmc$mcmc


## @knitr mcmcclip
tm <- window(m,1,320)
tm <- tm[,!grepl("^u\\.",colnames(m))]


## @knitr mcmcplot1
library("scapeMCMC")
plotTrace(tm)


## @knitr geweke
(gg <- geweke.diag(tm))
summary(2*pnorm(abs(gg$z),lower.tail=FALSE))


## @knitr codafuns,echo=FALSE
a1 <- apropos(".diag$",where=TRUE)
print(unname(a1[names(a1)==which(search()=="package:coda")]),
      quote=FALSE)


## @knitr effsize
range(effectiveSize(tm))


## @knitr HPDintervalCI
try(detach("package:lme4")) ## kluge!!
HPDinterval(tm)


## @knitr qCI
t(apply(tm,2,quantile,c(0.025,0.975)))


## @knitr eval=FALSE
## plotDens(tm)
## plotSplom(tm,pch=".")


## @knitr loaddat,echo=FALSE,eval=FALSE
## library("MASS")
## epil2 <- transform(epil,
##                    Base=log(base/4),
##                    Age=log(age),
##                    Visit=scale(period,center=TRUE,scale=5),
##                    subject=factor(subject))


## @knitr echo=FALSE,eval=FALSE
## ggplot(epil2,aes(x=base,y=log(1+y),colour=trt))+
##        stat_sum(aes(size=factor(..n..)),alpha=0.5)+
##   facet_wrap(~period)+
##   scale_x_log10()+geom_smooth()+zspace


## @knitr fit1,echo=FALSE,eval=FALSE
## fm <- glmmadmb(y~Base*trt+Age+Visit+(Visit|subject),
##                 data=epil2, family="nbinom")


## @knitr fit2,echo=FALSE,eval=FALSE
## fm2 <- glmmadmb(y~Base*trt+Age+Visit+(1|subject),
##                 data=epil2, family="nbinom")
## 


## @knitr echo=FALSE,eval=FALSE
## glm0 <- glm(y ~ lbase*trt + lage + V4, family = poisson,
##             data = epil)


## @knitr echo=FALSE,eval=FALSE
## ## stuff taken from help("epil",package="MASS")
## ## figure out what's going on here?  work this
## ## up into a reasonable comparison ...
## 
## ## basic GLM analysis
## summary(glm(y ~ lbase*trt + lage + V4, family = poisson,
##             data = epil), cor = FALSE)
## epil3 <- subset(epil,period == 1)
## epil3["period"] <- rep(0, 59); epil3["y"] <- epil3["base"]
## epil["time"] <- 1; epil3["time"] <- 4
## epil3 <- rbind(epil, epil3)
## epil3$pred <- unclass(epil3$trt) * (epil3$period > 0)
## epil3$subject <- factor(epil3$subject)
## epil3 <- aggregate(epil3, list(epil3$subject, epil3$period > 0),
##                    function(x) if(is.numeric(x)) sum(x) else x[1])
## epil3$pred <- factor(epil3$pred,
##                      labels = c("base", "placebo", "drug"))
## 
## contrasts(epil3$pred) <- structure(contr.sdif(3),
##                                    dimnames = list(NULL,
##                                      c("placebo-base", "drug-placebo")))
## summary(glm(y ~ pred + factor(subject) + offset(log(time)),
##             family = poisson, data = epil3), cor = FALSE)
## 
## summary(glmmPQL(y ~ lbase*trt + lage + V4,
##                 random = ~ 1 | subject,
##                 family = poisson, data = epil))
## summary(glmmPQL(y ~ pred, random = ~1 | subject,
##                 family = poisson, data = epil3))
## 


## @knitr echo=FALSE
detach("package:glmmADMB")
detach("package:ggplot2")


