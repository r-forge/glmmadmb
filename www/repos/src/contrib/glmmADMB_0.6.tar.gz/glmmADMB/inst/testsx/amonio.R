library(glmmADMB)

N <- read.csv("N.csv",colClasses=c(rep("factor",3),rep("numeric",2)))

m3 <- glmer(amonio~tratamiento+micrositio+(1|repeticion),
            family=Gamma(link="log"),data=na.omit(N))

g3 <- glmmadmb(amonio~tratamiento+micrositio+(1|repeticion),
           data=na.omit(N),family="gamma")

coef(g3)
fixef(m3)
VarCorr(g3)
VarCorr(m3)

g4 <- glmmadmb(amonio~tratamiento+micrositio+(1|repeticion),
           data=na.omit(N),family="gamma",link="inverse")


m4 <- glmer(amonio~tratamiento+micrositio+(1|repeticion),
            family=Gamma,data=na.omit(N))
