## grabbing and analyzing the r-sig-mixed-models archive
## e.g.




## https://mailman.stat.ethz.ch/pipermail/r-sig-mixed-models/2012q2.txt.gz
## goes back to 2007q1
